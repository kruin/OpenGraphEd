package userInterface;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;

import operation.KruinTreeDrawOperation;

public class KruinDialog extends GraphEditorDialog implements ActionListener
{
  public static int WIDTH = 560;
  public static int HEIGHT = 420;

  private static final String CONFIG_DIR = "config";
  private static final String DEFAULTS_FILE = CONFIG_DIR + File.separator + "kruin_defaults.properties";
  private static final String USER_FILE = CONFIG_DIR + File.separator + "kruin_user.properties";

  private static final String PROFILE_KRUIN = "kruin";
  private static final String PROFILE_PREVIOUS = "previous_open_structure";

  private GraphEditorWindow owner;

  private JButton runButton;
  private JButton kruinDefaultsButton;
  private JButton previousDefaultsButton;

  private JRadioButton simpleTreeButton;
  private JRadioButton languageTreeButton;
  private JRadioButton anaphorTreeButton;

  private JCheckBox showProjectionsBox;
  private JCheckBox leftProjectionBox;
  private JCheckBox rightProjectionBox;
  private JCheckBox topProjectionBox;
  private JCheckBox bottomProjectionBox;

  private JSpinner structureLeftOffsetSpinner;
  private JSpinner structureRightOffsetSpinner;
  private JSpinner structureTopOffsetSpinner;
  private JSpinner structureBottomOffsetSpinner;

  private JSpinner leftProjectionPositionSpinner;
  private JSpinner rightProjectionPositionSpinner;
  private JSpinner topProjectionPositionSpinner;
  private JSpinner bottomProjectionPositionSpinner;

  private JSpinner gridColumnWidthSpinner;
  private JSpinner gridRowHeightSpinner;

  private JComboBox defaultsProfileCombo;

  public KruinDialog( GraphController controller, GraphEditorWindow owner,
                      String title, String message )
  {
    super(controller, owner.getTitle() + " - " + title,
          true,
          true,
          true,
          false);
    this.owner = owner;

    getContentPane().setLayout(new BorderLayout(8, 8));

    JPanel mainPanel = new JPanel(new BorderLayout(8, 8));
    mainPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

    JPanel topPanel = new JPanel();
    topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));

    JLabel messageLabel = new JLabel(message, SwingConstants.LEFT);
    messageLabel.setAlignmentX(LEFT_ALIGNMENT);
    topPanel.add(messageLabel);

    JPanel commandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
    runButton = new JButton("Run");
    runButton.addActionListener(this);
    commandPanel.add(runButton);

    kruinDefaultsButton = new JButton("Kruin defaults");
    kruinDefaultsButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        applyKruinDefaultsToControls();
      }
    });
    commandPanel.add(kruinDefaultsButton);

    previousDefaultsButton = new JButton("Previous OpenStructure defaults");
    previousDefaultsButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        applyPreviousOpenStructureDefaultsToControls();
      }
    });
    commandPanel.add(previousDefaultsButton);

    topPanel.add(commandPanel);

    JPanel structurePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
    structurePanel.setBorder(BorderFactory.createTitledBorder("Structure Type"));
    ButtonGroup structureGroup = new ButtonGroup();

    simpleTreeButton = new JRadioButton("Simple tree");
    languageTreeButton = new JRadioButton("Language tree");
    anaphorTreeButton = new JRadioButton("Anaphor tree");

    structureGroup.add(simpleTreeButton);
    structureGroup.add(languageTreeButton);
    structureGroup.add(anaphorTreeButton);

    structurePanel.add(simpleTreeButton);
    structurePanel.add(languageTreeButton);
    structurePanel.add(anaphorTreeButton);
    topPanel.add(structurePanel);

    mainPanel.add(topPanel, BorderLayout.NORTH);
    mainPanel.add(createTabbedCenterPanel(), BorderLayout.CENTER);

    getContentPane().add(mainPanel, BorderLayout.CENTER);

    loadStartupSettings();

    addInternalFrameListener(controller);
    setBounds(650, 0, WIDTH, HEIGHT);
    setVisible(true);
  }

  private JTabbedPane createTabbedCenterPanel()
  {
    JTabbedPane tabs = new JTabbedPane();
    tabs.addTab("Projections", createProjectionsPanel());
    tabs.addTab("Positions", createPositionsPanel());
    tabs.addTab("Grid", createGridPanel());
    return tabs;
  }

  private JPanel createProjectionsPanel()
  {
    JPanel panel = new JPanel(new GridBagLayout());
    GridBagConstraints c = baseConstraints();

    showProjectionsBox = new JCheckBox("Show projections");
    panel.add(showProjectionsBox, c);

    c.gridy++;
    leftProjectionBox = new JCheckBox("Left projection");
    panel.add(leftProjectionBox, c);

    c.gridy++;
    rightProjectionBox = new JCheckBox("Right projection");
    panel.add(rightProjectionBox, c);

    c.gridy++;
    topProjectionBox = new JCheckBox("Top projection");
    panel.add(topProjectionBox, c);

    c.gridy++;
    bottomProjectionBox = new JCheckBox("Bottom projection");
    panel.add(bottomProjectionBox, c);

    c.gridy++;
    c.weighty = 1.0;
    panel.add(new JLabel(""), c);

    return panel;
  }

  private JPanel createPositionsPanel()
  {
    JPanel panel = new JPanel(new GridBagLayout());
    GridBagConstraints c = baseConstraints();

    addSpinnerRow(panel, c, "Structure from left projection", structureLeftOffsetSpinner = spinner(0, 500, 2));
    addSpinnerRow(panel, c, "Structure from right projection", structureRightOffsetSpinner = spinner(0, 500, 2));
    addSpinnerRow(panel, c, "Structure from top projection", structureTopOffsetSpinner = spinner(0, 500, 2));
    addSpinnerRow(panel, c, "Structure from bottom projection", structureBottomOffsetSpinner = spinner(0, 500, 2));

    addSpinnerRow(panel, c, "Left projection position", leftProjectionPositionSpinner = spinner(0, 500, 2));
    addSpinnerRow(panel, c, "Right projection position", rightProjectionPositionSpinner = spinner(0, 500, 30));
    addSpinnerRow(panel, c, "Top projection position", topProjectionPositionSpinner = spinner(0, 500, 0));
    addSpinnerRow(panel, c, "Bottom projection position", bottomProjectionPositionSpinner = spinner(0, 500, 30));

    c.gridy++;
    c.weighty = 1.0;
    panel.add(new JLabel(""), c);

    return panel;
  }

  private JPanel createGridPanel()
  {
    JPanel panel = new JPanel(new GridBagLayout());
    GridBagConstraints c = baseConstraints();

    addSpinnerRow(panel, c, "Grid column width", gridColumnWidthSpinner = spinner(5, 200, 20));
    addSpinnerRow(panel, c, "Grid row height", gridRowHeightSpinner = spinner(5, 200, 20));

    c.gridy++;
    c.gridx = 0;
    c.gridwidth = 1;
    c.weightx = 0.0;
    panel.add(new JLabel("Defaults profile"), c);

    c.gridx = 1;
    c.weightx = 1.0;
    defaultsProfileCombo = new JComboBox(new String[]{"Kruin defaults", "Previous OpenStructure defaults"});
    panel.add(defaultsProfileCombo, c);

    c.gridy++;
    c.gridx = 0;
    c.gridwidth = 2;
    c.weighty = 1.0;
    panel.add(new JLabel(""), c);

    return panel;
  }

  private GridBagConstraints baseConstraints()
  {
    GridBagConstraints c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 2;
    c.insets = new Insets(4, 4, 4, 4);
    c.anchor = GridBagConstraints.NORTHWEST;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.weightx = 1.0;
    c.weighty = 0.0;
    return c;
  }

  private void addSpinnerRow(JPanel panel, GridBagConstraints c, String label, JSpinner spinner)
  {
    c.gridwidth = 1;
    c.gridx = 0;
    c.weightx = 0.0;
    panel.add(new JLabel(label), c);

    c.gridx = 1;
    c.weightx = 1.0;
    panel.add(spinner, c);

    c.gridy++;
    c.gridx = 0;
  }

  private JSpinner spinner(int min, int max, int value)
  {
    return new JSpinner(new SpinnerNumberModel(value, min, max, 1));
  }

  public int getStructureType()
  {
    if ( languageTreeButton.isSelected() )
    {
      return KruinTreeDrawOperation.STRUCTURE_TYPE_LANGUAGE_TREE;
    }
    if ( anaphorTreeButton.isSelected() )
    {
      return KruinTreeDrawOperation.STRUCTURE_TYPE_ANAPHOR_TREE;
    }
    return KruinTreeDrawOperation.STRUCTURE_TYPE_SIMPLE_TREE;
  }

  public boolean getShowProjections() { return showProjectionsBox.isSelected(); }
  public boolean getLeftProjectionEnabled() { return leftProjectionBox.isSelected(); }
  public boolean getRightProjectionEnabled() { return rightProjectionBox.isSelected(); }
  public boolean getTopProjectionEnabled() { return topProjectionBox.isSelected(); }
  public boolean getBottomProjectionEnabled() { return bottomProjectionBox.isSelected(); }

  public int getStructureOffsetFromLeft() { return intValue(structureLeftOffsetSpinner); }
  public int getStructureOffsetFromRight() { return intValue(structureRightOffsetSpinner); }
  public int getStructureOffsetFromTop() { return intValue(structureTopOffsetSpinner); }
  public int getStructureOffsetFromBottom() { return intValue(structureBottomOffsetSpinner); }

  public int getLeftProjectionPosition() { return intValue(leftProjectionPositionSpinner); }
  public int getRightProjectionPosition() { return intValue(rightProjectionPositionSpinner); }
  public int getTopProjectionPosition() { return intValue(topProjectionPositionSpinner); }
  public int getBottomProjectionPosition() { return intValue(bottomProjectionPositionSpinner); }

  public int getGridColumnWidth() { return intValue(gridColumnWidthSpinner); }
  public int getGridRowHeight() { return intValue(gridRowHeightSpinner); }

  public boolean usePreviousOpenStructureDefaultsSelected()
  {
    return defaultsProfileCombo.getSelectedIndex() == 1;
  }

  public void saveUserPreferences()
  {
    Properties props = new Properties();
    props.setProperty("structure.type", String.valueOf(getStructureType()));
    props.setProperty("defaults.profile", usePreviousOpenStructureDefaultsSelected() ? PROFILE_PREVIOUS : PROFILE_KRUIN);

    props.setProperty("projections.show", String.valueOf(getShowProjections()));
    props.setProperty("projections.left.enabled", String.valueOf(getLeftProjectionEnabled()));
    props.setProperty("projections.right.enabled", String.valueOf(getRightProjectionEnabled()));
    props.setProperty("projections.top.enabled", String.valueOf(getTopProjectionEnabled()));
    props.setProperty("projections.bottom.enabled", String.valueOf(getBottomProjectionEnabled()));

    props.setProperty("structure.offset.left", String.valueOf(getStructureOffsetFromLeft()));
    props.setProperty("structure.offset.right", String.valueOf(getStructureOffsetFromRight()));
    props.setProperty("structure.offset.top", String.valueOf(getStructureOffsetFromTop()));
    props.setProperty("structure.offset.bottom", String.valueOf(getStructureOffsetFromBottom()));

    props.setProperty("projection.left.position", String.valueOf(getLeftProjectionPosition()));
    props.setProperty("projection.right.position", String.valueOf(getRightProjectionPosition()));
    props.setProperty("projection.top.position", String.valueOf(getTopProjectionPosition()));
    props.setProperty("projection.bottom.position", String.valueOf(getBottomProjectionPosition()));

    props.setProperty("grid.column.width", String.valueOf(getGridColumnWidth()));
    props.setProperty("grid.row.height", String.valueOf(getGridRowHeight()));

    saveProperties(new File(USER_FILE), props);
  }

  private void loadStartupSettings()
  {
    applyPropertiesToControls(loadProperties(new File(DEFAULTS_FILE)));

    File userFile = new File(USER_FILE);
    if ( userFile.exists() )
    {
      applyPropertiesToControls(loadProperties(userFile));
    }
    else
    {
      applyKruinDefaultsToControls();
      simpleTreeButton.setSelected(true);
    }
  }

  private void applyPropertiesToControls(Properties props)
  {
    if ( props == null )
    {
      applyKruinDefaultsToControls();
      simpleTreeButton.setSelected(true);
      return;
    }

    setStructureType(parseInt(props.getProperty("structure.type"), KruinTreeDrawOperation.STRUCTURE_TYPE_SIMPLE_TREE));

    String profile = props.getProperty("defaults.profile", PROFILE_KRUIN);
    defaultsProfileCombo.setSelectedIndex(PROFILE_PREVIOUS.equals(profile) ? 1 : 0);

    showProjectionsBox.setSelected(parseBoolean(props.getProperty("projections.show"), true));
    leftProjectionBox.setSelected(parseBoolean(props.getProperty("projections.left.enabled"), true));
    rightProjectionBox.setSelected(parseBoolean(props.getProperty("projections.right.enabled"), false));
    topProjectionBox.setSelected(parseBoolean(props.getProperty("projections.top.enabled"), true));
    bottomProjectionBox.setSelected(parseBoolean(props.getProperty("projections.bottom.enabled"), false));

    structureLeftOffsetSpinner.setValue(new Integer(parseInt(props.getProperty("structure.offset.left"), 2)));
    structureRightOffsetSpinner.setValue(new Integer(parseInt(props.getProperty("structure.offset.right"), 2)));
    structureTopOffsetSpinner.setValue(new Integer(parseInt(props.getProperty("structure.offset.top"), 2)));
    structureBottomOffsetSpinner.setValue(new Integer(parseInt(props.getProperty("structure.offset.bottom"), 2)));

    leftProjectionPositionSpinner.setValue(new Integer(parseInt(props.getProperty("projection.left.position"), 2)));
    rightProjectionPositionSpinner.setValue(new Integer(parseInt(props.getProperty("projection.right.position"), 30)));
    topProjectionPositionSpinner.setValue(new Integer(parseInt(props.getProperty("projection.top.position"), 0)));
    bottomProjectionPositionSpinner.setValue(new Integer(parseInt(props.getProperty("projection.bottom.position"), 30)));

    gridColumnWidthSpinner.setValue(new Integer(parseInt(props.getProperty("grid.column.width"), 20)));
    gridRowHeightSpinner.setValue(new Integer(parseInt(props.getProperty("grid.row.height"), 20)));
  }

  private void applyKruinDefaultsToControls()
  {
    simpleTreeButton.setSelected(true);
    defaultsProfileCombo.setSelectedIndex(0);

    showProjectionsBox.setSelected(true);
    leftProjectionBox.setSelected(true);
    rightProjectionBox.setSelected(false);
    topProjectionBox.setSelected(true);
    bottomProjectionBox.setSelected(false);

    structureLeftOffsetSpinner.setValue(new Integer(2));
    structureRightOffsetSpinner.setValue(new Integer(2));
    structureTopOffsetSpinner.setValue(new Integer(2));
    structureBottomOffsetSpinner.setValue(new Integer(2));

    leftProjectionPositionSpinner.setValue(new Integer(2));
    rightProjectionPositionSpinner.setValue(new Integer(30));
    topProjectionPositionSpinner.setValue(new Integer(0));
    bottomProjectionPositionSpinner.setValue(new Integer(30));

    gridColumnWidthSpinner.setValue(new Integer(20));
    gridRowHeightSpinner.setValue(new Integer(20));
  }

  private void applyPreviousOpenStructureDefaultsToControls()
  {
    simpleTreeButton.setSelected(true);
    defaultsProfileCombo.setSelectedIndex(1);

    showProjectionsBox.setSelected(true);
    leftProjectionBox.setSelected(true);
    rightProjectionBox.setSelected(false);
    topProjectionBox.setSelected(true);
    bottomProjectionBox.setSelected(false);

    structureLeftOffsetSpinner.setValue(new Integer(2));
    structureRightOffsetSpinner.setValue(new Integer(2));
    structureTopOffsetSpinner.setValue(new Integer(2));
    structureBottomOffsetSpinner.setValue(new Integer(2));

    leftProjectionPositionSpinner.setValue(new Integer(0));
    rightProjectionPositionSpinner.setValue(new Integer(30));
    topProjectionPositionSpinner.setValue(new Integer(0));
    bottomProjectionPositionSpinner.setValue(new Integer(30));

    gridColumnWidthSpinner.setValue(new Integer(20));
    gridRowHeightSpinner.setValue(new Integer(20));
  }

  private void setStructureType(int structureType)
  {
    if ( structureType == KruinTreeDrawOperation.STRUCTURE_TYPE_LANGUAGE_TREE )
    {
      languageTreeButton.setSelected(true);
    }
    else if ( structureType == KruinTreeDrawOperation.STRUCTURE_TYPE_ANAPHOR_TREE )
    {
      anaphorTreeButton.setSelected(true);
    }
    else
    {
      simpleTreeButton.setSelected(true);
    }
  }

  private int intValue(JSpinner spinner)
  {
    return ((Integer)spinner.getValue()).intValue();
  }

  private Properties loadProperties(File file)
  {
    if ( !file.exists() )
    {
      return null;
    }

    Properties props = new Properties();
    FileInputStream in = null;
    try
    {
      in = new FileInputStream(file);
      props.load(in);
      return props;
    }
    catch ( IOException e )
    {
      return null;
    }
    finally
    {
      if ( in != null )
      {
        try { in.close(); } catch ( IOException e ) { }
      }
    }
  }

  private void saveProperties(File file, Properties props)
  {
    File parent = file.getParentFile();
    if ( parent != null && !parent.exists() )
    {
      parent.mkdirs();
    }

    FileOutputStream out = null;
    try
    {
      out = new FileOutputStream(file);
      props.store(out, "Kruin user preferences");
    }
    catch ( IOException e )
    {
      e.printStackTrace();
    }
    finally
    {
      if ( out != null )
      {
        try { out.close(); } catch ( IOException e ) { }
      }
    }
  }

  private int parseInt(String value, int defaultValue)
  {
    try
    {
      return Integer.parseInt(value);
    }
    catch ( Exception e )
    {
      return defaultValue;
    }
  }

  private boolean parseBoolean(String value, boolean defaultValue)
  {
    if ( value == null )
    {
      return defaultValue;
    }
    return Boolean.valueOf(value).booleanValue();
  }

  public void enableRunButton() { runButton.setEnabled(true); }
  public void disableRunButton() { runButton.setEnabled(false); }

  public GraphEditorWindow getOwner() { return owner; }
  public void setOwner(GraphEditorWindow o) { owner = o; }

  public void actionPerformed(ActionEvent e)
  {
    // overridden by anonymous subclass in GraphController
  }
}
